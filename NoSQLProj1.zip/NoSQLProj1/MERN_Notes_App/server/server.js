// Importing Modules
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config(); // Environment Variables
const dbURL = "mongodb://localhost:27017/memotes1";

// Initialize Express
const app = express();

// Middleware
app.use(express.json()); // JSON Parser
app.use(express.urlencoded({ extended: true })); // URL Body Parser

// CORS Configuration
app.use(
  cors({
    origin: "*",
    // credentials: true, // Uncomment if credentials are needed
  })
);

// Database Connection
mongoose
  .connect(dbURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to MongoDB!");
    // Start server after DB connection is successful
    app.listen(process.env.PORT || 3000, () => {
      console.log(`Server running on port ${process.env.PORT || 3000}`);
    });
  })
  .catch((error) => console.log("Database connection error:", error));

// Routes
const routes = require("./routes/routes");
app.use(routes);
